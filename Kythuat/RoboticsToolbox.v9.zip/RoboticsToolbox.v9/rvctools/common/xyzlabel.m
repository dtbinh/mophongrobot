xlabel('x');
ylabel('y');
zlabel('z');
